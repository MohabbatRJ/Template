<template>
  <Home></Home>
</template>

<script>

import Home from './components/Home'
export default {
  components: { Home },
  name: 'App',
  
}
</script>

<style>
   @import './assets/css/style.css'
</style>
