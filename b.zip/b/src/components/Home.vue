<template>
    <div>
        <Header></Header>
        <MainBlog></MainBlog>
    </div>
</template>

<script>
import MainBlog from './Blogs/MainBlog'
import Header from './sectionHead/Header'
    export default {
  components: {
    MainBlog, Header },
        name : 'HomeBlog'
    }
</script>

<style scoped>

</style>