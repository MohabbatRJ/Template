<template>
<section class="blogs" id="blogs">
    <div class="container">

        <div class="d-flex flex-wrap blog-actions justify-content-between">
            <div class="blog-nav">
                <div class="blog-nav__wrapper position-relative">
                    <div class="d-flex align-items-center d-xl-none">
                        <h6>Category </h6>
                        <button type="button" class="btn open-dropdown">
                            <i class="icon toggle-icon"></i>
                        </button>
                    </div>

                    <BlogNav :selectedCategory="selectedCategory" @category-selected="handleCategorySelected" :categories="allCategories"></BlogNav>
                </div>
            </div>

            <BlogSearch @search-query-changed="handleSearchQueryChange"></BlogSearch>
        </div>

        <div class="tab-content">

            <div class="tab-pane active show" id="blog-tab" role="tabpanel">
                <AllBlogs :allblogs="slicedBlogs" :allImages="allImages"></AllBlogs>
            </div>
        </div>

        <BlogPagination :totalBlogs="filteredBlogs.length" :blogsPerPage="blogsPerPage" :currentPage="currentPage" @page-changed="handlePageChange">
        </BlogPagination>
    </div>
</section>
</template>

<script>
import axios from 'axios'
import AllBlogs from './blogComponents/AllBlogs'
import BlogSearch from './blogComponents/BlogSearch'
import BlogNav from './blogComponents/BlogNav'
import BlogPagination from './blogComponents/BlogPagination'
export default {
    name: 'MainBlog',

    data() {
        return {
            allblogs: [],
            allImages: [],
            category: [],
            selectedCategory: 'all',
            currentPage: 1,
            blogsPerPage: 4,
            searchQuery: '',
        }
    },

    components: {
        AllBlogs,
        BlogSearch,
        BlogNav,
        BlogPagination
    },

    async mounted() {
        let response = await axios.get('https://api.slingacademy.com/v1/sample-data/blog-posts');
        console.log('Posts:', response.data.blogs);
        this.allblogs = response.data.blogs;

        let imageApi = await axios.get('https://api.slingacademy.com/v1/sample-data/photos');
        console.log('images', imageApi.data.photos)
        this.allImages = imageApi.data.photos;
    },

    methods: {
        handleCategorySelected(category) {
            this.selectedCategory = category;
            // console.log(this.selectedCategory, 'selectCategory', category, 'category');
        },
        handlePageChange(pageNumber) {
            this.currentPage = pageNumber;
        },
        clearSearchQuery() {
            this.searchQuery = "";
        },
        handleSearchQueryChange(query) {
            this.searchQuery = query;
            this.currentPage = 1; 
            if (query.trim() === "") {
                this.clearSearchQuery();
            }

            console.log('Search Query:', query);
        },

    },

    computed: {
        // Compute filtered blogs based on the selected category
        // filteredBlogs() {
        //     if (this.selectedCategory === 'all') {
        //         return this.allblogs; // Return all blogs if 'all' category is selected
        //     } else {

        //         console.log('cat', this.allblogs.filter((blog) => blog.category === this.selectedCategory));
        //         return this.allblogs.filter((blog) => blog.category === this.selectedCategory);
        //     }
        // },
        slicedBlogs() {
            const startIndex = (this.currentPage - 1) * this.blogsPerPage;
            const endIndex = startIndex + this.blogsPerPage;
            return this.filteredBlogs.slice(startIndex, endIndex);
        },
        filteredBlogs() {
            let filteredBlogs = this.allblogs;
            if (this.selectedCategory !== "all") {
                filteredBlogs = filteredBlogs.filter(
                    (blog) => blog.category === this.selectedCategory
                );

            }

            if (this.searchQuery.trim() !== "") {
                const lowercaseQuery = this.searchQuery.trim().toLowerCase();
                filteredBlogs = filteredBlogs.filter(
                    (blog) =>
                    blog.title.toLowerCase().includes(lowercaseQuery) ||
                    blog.description.toLowerCase().includes(lowercaseQuery)
                );
            }
            console.log('search', filteredBlogs)
            return filteredBlogs;
        },

        allCategories() {
            const uniqueCategories = new Set();
            this.allblogs.forEach((blog) => {
                uniqueCategories.add(blog.category);
            });
            return Array.from(uniqueCategories);
        },
    },

    watch: {
        currentPage(newPage) {
            this.slicedBlogs = this.filteredBlogs.slice(
                (newPage - 1) * this.blogsPerPage,
                newPage * this.blogsPerPage
            );
        },
    },
}
</script>

<style scoped>

</style>
