<template>
<ul class="nav nav-pills mb-36 flex-column flex-xl-row" role="tablist" >
    <li class="nav-item" role="presentation">
        <a class="nav-link" data-bs-toggle="pill" aria-selected="true" role="tab" @click="selectCategory('all')" :class="{ active: selectedCategory === 'all' }">Blogs</a>
    </li>
    <li class="nav-item" role="presentation" v-for="(category, index) in categories" :key="index">
        <a class="nav-link" data-bs-toggle="pill" aria-selected="true" role="tab" :class="{ active: selectedCategory === category }"
        @click="selectCategory(category)">{{ category }}</a>
    </li>
    <!-- <li class="nav-item" role="presentation">
        <a class="nav-link" data-bs-toggle="pill" aria-selected="false" role="tab" tabindex="-1" @click="selectCategory('math')" :class="{ active: selectedCategory === 'math' }">Math</a>
    </li>
    <li class="nav-item" role="presentation">
        <a class="nav-link" data-bs-toggle="pill" aria-selected="false" role="tab" tabindex="-1" @click="selectCategory('gaming')" :class="{ active: selectedCategory === 'gaming' }">Gaming</a>
    </li>
    <li class="nav-item" role="presentation">
        <a class="nav-link" data-bs-toggle="pill" aria-selected="false" role="tab" tabindex="-1" @click="selectCategory('programming')" :class="{ active: selectedCategory === 'programming' }">Programming</a>
    </li> -->
    <!-- <li class="nav-item" role="presentation">
        <a class="nav-link" data-bs-toggle="pill" href="#space-tab" aria-selected="false" role="tab" tabindex="-1">Space</a>
    </li>
    <li class="nav-item" role="presentation">
        <a class="nav-link" data-bs-toggle="pill" href="#business-tab" aria-selected="false" role="tab" tabindex="-1">business</a>
    </li> -->
</ul>
</template>

<script>
export default {
    name: 'BlogNav',
    props: {
      selectedCategory: String, 
      categories: Array,
    },
    methods: {
      selectCategory(category) {
        this.$emit('category-selected', category);
      },
    },
  };
</script>

<style scoped>
a{
    cursor: pointer;
}
</style>


  