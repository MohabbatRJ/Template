<template>
<div class="blog-search">
    <div class="blog-search-container ms-auto">
        <form @submit.prevent action="#" method="post" class="form-search" name="form-search" id="form-search">
            <div class="input-group overflow-hidden">
                <input type="text" class="form-control border-0 search-input" placeholder="Search here" v-model="searchQuery" @input="handleSearchInputChange" @keydown.enter.prevent>
                <button class="btn form-search-submit" type="submmit">
                    <i class="fa fa-search" aria-hidden="true"></i>
                </button>
            </div>
        </form>
    </div>
</div>
</template>

<script>
export default {
    name: 'BlogSearch',
    data() {
        return {
            searchQuery: '',
        };
    },
    methods: {
        handleSearchInputChange() {
      this.$emit("search-query-changed", this.searchQuery);

      // Check if the input is cleared and emit an empty query
      if (this.searchQuery.trim() === "") {
        this.$emit("search-query-changed", "");
      }
    },
    },
}
</script>

<style scoped>

</style>
