<template>
<div class="d-grid blogs-article-3cols">

    <!-- Full Width Card -->

    <div class="card border-0 d-flex flex-row-reverse flex-wrap align-items-center" v-for="(blog, index) in allblogs" :key="blog.id" :class="{ ' card--full': index === 0 }">
        <div class="card-img" >
            <a href="#" class="d-block" > 
                <img :src="blog.photo_url" alt="" :width="index === 0 ? '579' : '372'" :height="index === 0 ? '262' : '231'" class="w-100 pulse">
            </a>
        </div>

        <div class="card-body p-0">
            <div class="card-body-wrapper">
                <div class="card-info align-items-center">
                    <div class="card-category">
                        <a href="#">{{blog.category != '' ? blog.category : 'Uncategorized'}}</a>
                    </div>

                    <div class="card-publish">
                        <ul class="d-flex flex-wrap mb-0">
                            <li><i>by</i> &nbsp; <a href="#">{{blog.author == '' ? blog.author : 'Linentech'}}</a></li>
                            <li>{{new Date(blog.updated_at).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })}}</li>
                        </ul>
                    </div>
                </div>

                <h5><a href="#">{{blog.title}}</a></h5>
                <p class="card-short-description">{{blog.description}}</p>
                <a href="#" class="btn p-0">Read More</a>
            </div>
        </div>
    </div>

    <!-- 1/3 Width Card -->
    <!--
    <div class="card border-0" v-for="blog in allblogs" :key="blog.id">
        <div class="card-body-wrapper">
            <div class="card-img">
                <a href="#" class="d-block">
                    <img src="../../../assets/blog-img-1.webp" alt="" width="372" height="231" class="w-100">
                </a>
            </div>

            <div class="card-body p-0">
                <div class="card-info align-items-center">
                    <div class="card-category">
                        <a href="#">{{blog.category}}</a>
                    </div>

                    <div class="card-publish">
                        <ul class="d-flex flex-wrap mb-0">
                            <li><i>by</i> &nbsp; <a href="#">LinenTech</a></li>
                            <li>{{new Date(blog.updated_at).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })}}</li>
                        </ul>
                    </div>
                </div>

                <h5><a href="#">{{ blog.title }}</a></h5>
                <p class="card-short-description">{{blog.description}}</p>
                <a href="#" class="btn p-0">Read More</a>
            </div>
        </div>
    </div>
    -->

</div>
</template>

<script>
export default {
    name: 'AllBlogs',
    data() {
        return {
            //   blog: {
            //     updated_at: "2023-03-16T19:06:12.184272", // Replace with the date from your API
            //   },
        };
    },
    props: {
        allblogs: Array,
        allImages: Array,

    },
    //     computed: {
    //     formattedUpdatedAt() {
    //       const options = { year: 'numeric', month: 'short', day: '2-digit' };
    //       const date = new Date(this.blog.updated_at);
    //       return date.toLocaleDateString(undefined, options);
    //     },
    //   },
    }
</script>

<style scoped>

</style>
