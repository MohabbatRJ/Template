<template>
<ul class="pagination justify-content-center">
    <li class="page-item" :class="{ 'disabled': currentPage === 1 }">
        <a class="page-link" @click="changePage(currentPage - 1)" href="#">Previous</a>
    </li>
    <li v-for="pageNumber in totalPages" :key="pageNumber" class="page-item" :class="{ 'active': pageNumber === currentPage }">
        <a class="page-link" @click="changePage(pageNumber)" href="#">{{ pageNumber }}</a>
    </li>
    <li class="page-item" :class="{ 'disabled': currentPage === totalPages }">
        <a class="page-link" @click="changePage(currentPage + 1)" href="#">Next</a>
    </li>
</ul>
</template>

<script>
export default {
    name: 'BlogPagination',
    props: {
        totalBlogs: Number,
        blogsPerPage: Number,
        currentPage: Number,
    },
    computed: {
        totalPages() {
            return Math.ceil(this.totalBlogs / this.blogsPerPage);
        },
    },
    methods: {
    changePage(pageNumber) {
      if (pageNumber >= 1 && pageNumber <= this.totalPages) {
        this.$emit('page-changed', pageNumber);
      }
    }
},
}
</script>

<style scoped>
.active{
    color: #fff !important;
}
</style>
