<template>
    <section class="hero hero--about bg-transparent background" id="hero">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-xxl-8 col-xl-8 col-lg-10 col-md-12 col-sm-12 col-12">
                <div class="hero__content">
                    <!--<h4 class="hero__sub-heading mb-2 mt-3 mt-lg-0">commercial laundry management system</h4>-->
                    <h1 class="mb-3 mb-md-2">Leading the Way in Tech</h1>

                    <p>Insights and Inspiration from the LinenTech Blog.</p>
                </div>
            </div>
        </div>
    </div>
    </section>
</template>

<script>
export default {
    name: 'HeaderSection',
}
</script>

<style scoped>

</style>
